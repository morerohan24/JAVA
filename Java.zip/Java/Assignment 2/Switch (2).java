import java.util.*;

public class Switch 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 for Area of circle\n 2 for check whether the no is positive or negavtive\n 3 for exit your program");
		int num=sc.nextInt();
		switch(num)
		{
		case 1:
			double r,pi,ac;
			pi=3.142;
			System.out.println("Enter radius:");
			r=sc.nextDouble();
			ac=pi*r*r;
			System.out.println("Area of circle is:"+ac);
			break;
		case 2:
			int n;
			System.out.println("Enter the no you want to check");
			n=sc.nextInt();
			if(n>0)
				System.out.println(n+" is a positive no");
			else
				System.out.println(n+" is a negative no");
			break;
		case 3:
			System.out.println("You have exit your program");
			break;
		default:
			System.out.println("Please enter valid no");		
		}
	}

}
