public class SimpleIntrest
{
  public static void main(String args[])
   {
     int n,p;
     double r,si;
     n=Integer.parseInt(args[0]);
     p=Integer.parseInt(args[1]);
     r=Double.parseDouble(args[2]);
     si=(n*p*r)/100;
     System.out.println("Simple Intrest is:"+si);
    }
}