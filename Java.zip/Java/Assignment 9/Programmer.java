import java.io.*;
import java.util.*;
class Company
{
	public String comp_name,address,mail_id;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	 
	 public void caccept()throws IOException
	 {
		 System.out.println("Enter Company name,address,email id:=");
		 comp_name=br.readLine();
		 address=br.readLine();
		 mail_id=br.readLine();
	 }
	public void cdisplay()
	{
	 System.out.println("Company name is:="+comp_name+"\nCompany address is :="+address+ "\nCompany email id is:="+mail_id);
		
	}
	public void payslip()
	{
		System.out.println("Display company salary details:=");
	}
}
public class Programmer extends Company
{
	public String pname,designation;
	public double basic_salary,ha,da,ta,gs,ns;
	Scanner sc =new Scanner (System.in);
	
	Programmer()
	{
		ha=4000;
		da=7000;
		ta=2000;
	}
	public void paccept()throws IOException
	{
		caccept();
		System.out.println("Enter programmer name,designation,basic salary:");
		pname=br.readLine();
		designation=br.readLine();
		basic_salary=sc.nextDouble();
		
	}
	public void payslip()
	{
		gs=(ha+da+ta+basic_salary);
		System.out.println("Gross Salary is :="+gs);
		
		ns=gs*12;
		System.out.println("Net Salary is:="+ns);
	}
	public void pdisplay()
	{
	 cdisplay();	
         System.out.println("Programmer name:"+pname+"\tDesignation:="+designation+"\tBasic Salary          is:="+basic_salary);
	payslip();
	}

	public static void main(String []args)throws IOException
	{
		Programmer p[]=new Programmer[100];
		int i,n;
		Scanner sc=new Scanner (System.in);
		System.out.println("How many programmers in the company:=");
		n=sc.nextInt();
		
		System.out.println("Accept Details:");
		  for(i=0;i<n;i++)
		  {
			  p[i]=new Programmer();
			  p[i].paccept();
		  }
		  System.out.println("Display Details:");
			
		  for(i=0;i<n;i++)
		  {
			 p[i].pdisplay();
		  }
	}
}