import java.util.*;
import java.io.*;
public class Overloading 
   {
    public int a,b,c,d;
    public double x,y,z;
    public String s1,s2,s3;
    Scanner sc=new Scanner(System.in);
	
    public int add()
    {
    	return a+b;
    }
	
    public void add(int m,int n)
    {
      int res;
      res=m+n;
      System.out.println("Addtion of 2 integer is:"+res);
    }
	
    public void add(int m,int n,int o)
    {
    	int res;
    	res=m+n+o;
    	System.out.println("Addtion of 3 integer is:"+res);
    }
    
    public void add(double p,double q)
    {
    	double res;
        res=p+q;
    	System.out.println("Addtion of 2 double is:"+res);
    }
  
    public void add(double p,double q,double r)
    {
    	double res;
        res=p+q+r;
    	System.out.println("Addtion of 3 double is:"+res);
    }
    
    public void add(String m,String n)
    {
    	String res=m+" "+n;
    	System.out.println("Addtion of 2 string"+res);
    }

    public void accept()throws IOException
    {
    	System.out.println("Enter the 3 integer");
    	a=sc.nextInt();
        b=sc.nextInt();
        c=sc.nextInt();
       
        System.out.println("Enter the 3 double");
    	x=sc.nextDouble();
        y=sc.nextDouble();
        z=sc.nextDouble();
    
        System.out.println("Enter the 2 string");
    	s1=sc.next();
        s2=sc.next();
       
    }
    public static void main(String[] args)throws IOException 
    {
		    	
        Overloading obj=new Overloading();
    	obj.accept();
    	
    	obj.c=obj.add();
    	System.out.println("Addtion is:"+obj.c);
	    
    	obj.add(obj.a,obj.b);
    	obj.add(10,20);
        
    	obj.add(obj.a,obj.b,obj.c);
    	obj.add(1,2,3);
    
    	obj.add(obj.x,obj.y);
    	obj.add(1.1,2.2);

        obj.add(obj.x,obj.y,obj.z);
    	obj.add(11.5,22.5,33.5);
   
        obj.add(obj.s1,obj.s2);
    	obj.add("vaishnavi","om");
     }
}