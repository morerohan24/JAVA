import java.io.*;
import java.util.*;
class Worker
{
	public String name,Address;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public void waccept()throws IOException
	{
		System.out.println("Enter Workers name and adress:-");
		name=br.readLine();
		Address=br.readLine();
	}
	public void wdisplay()
	{
		System.out.println("Workers name is "+name+" and his Address is "+Address);
	}
}

class FullTimeWorker extends Worker
{
	public String department;
	public double salary;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	public void faccept()throws IOException
	{
		waccept();
		System.out.println("Enter workers department and salary:-");
		department=br.readLine();
		salary=Double.parseDouble(br.readLine());
	}
	public void fdisplay()
	{
		wdisplay();
		System.out.println("Workers department is "+department+" and his salary is "+salary);
	}
}

class PartTimeWorker extends Worker
{
	int no_of_hr;
	double rate_per_hr,salary;
	public void paccept()throws IOException
	{
		waccept();
		System.out.println("Enter No of hours and rate per hour:-");
		no_of_hr=Integer.parseInt(br.readLine());
		rate_per_hr=Double.parseDouble(br.readLine());
		

	}
	public void cal_salary()
	{
		salary=no_of_hr*rate_per_hr;
		System.out.println("\nTotal salary of worker is :-"+salary);
	}
	public void pdisplay()
	{
		wdisplay();
		System.out.println("Worker number of hours is "+no_of_hr+" and rate per hour is "+rate_per_hr);
	}
}


public class WorkerDetails {


	public static void main(String[] args)throws IOException
	{
		
		FullTimeWorker f1[]=new FullTimeWorker[100];
		PartTimeWorker p1[]=new PartTimeWorker[100];
		int i,num1,num2;
		Scanner sc=new Scanner(System.in);
		System.out.println("how many full time worker you want:-");
		num1=sc.nextInt();
		System.out.println("Accept details of full time worker:-");
		for(i=0;i<num1;i++)
		{
			f1[i]=new FullTimeWorker();
			f1[i].faccept();
		}
		System.out.println("Display full time workers details:-");
		for(i=0;i<num1;i++)
		{
			f1[i].fdisplay();
		}
		System.out.println("How many part time worker you want:-");
		num2=sc.nextInt();
		System.out.println("Accept details of part time worker:-");
		for(i=0;i<num2;i++)
		{
			p1[i]=new PartTimeWorker();
			p1[i].paccept();
		}
		System.out.println("Display full time workers details:-");
		for(i=0;i<num2;i++)
		{ 
			
			p1[i].pdisplay();
			p1[i].cal_salary();
		}
		
		
	}

}