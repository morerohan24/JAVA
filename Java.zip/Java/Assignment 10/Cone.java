abstract class Shape
{
  abstract void Area();
}
class Sphere extends Shape
{
  public void Area()
  {
    int r=2;
    double sarea=4*3.14*r*r;
    System.out.println("Area of sphere is:"+sarea);
  }
}
public class Cone extends Shape
{
 public void Area()
 {
   int r=4,s=10;
   double pi=3.14,carea=pi*r*s+pi*r*r;
   System.out.println("Area of cone is:"+carea);
 }
public static void main(String args[])
{
  Sphere s1=new Sphere();
  s1.Area();
  Cone c1=new Cone();
  c1.Area();
}
}