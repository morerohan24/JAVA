public class Vehicle 
{
  public String name;
  public final int speed=300;

  public void display()
  {
     System.out.println("Vehicle name is:"+name+ "\tspeed is:"+speed);
  }
	
  public static void main(String[] args) 
  {
    Vehicle v1 = new Vehicle();
    v1.name="s-cross";
    v1.display();
  }
}