package Company;
import java.io.*;
import java.util.*;

public class Emp
{
  public String name,category;
  public int empid;
  public double bpay,hra,da,npay,pf,grosspay;
  Scanner sc=new Scanner(System.in);

public void eaccept()throws IOException
{
  System.out.println("Enter employee name,empid,category,bpay,hra,da,pf");
  name=sc.next();
  empid=sc.nextInt();
  category=sc.next();
  bpay=sc.nextDouble();
  hra=sc.nextDouble();
  da=sc.nextDouble();
  pf=sc.nextDouble();
}

public void cal_salary()
{
 grosspay=bpay+hra+da+pf;
 npay=grosspay*12;
}
 
public void edisplay()
{
  System.out.println("Employee name is:"+name+"\nId is:"+empid+"\nCategory is:"+category+"\nBasic salary is:"+bpay+"\nHome allowance is:"+hra+"\nDaily allowance is:"+da+"\n Pf amount is:"+pf+
"\nGrosspay is:"+grosspay+"\nNet salary amount is:"+npay);
}
}