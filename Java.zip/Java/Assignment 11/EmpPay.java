import Company.Emp;
import java.io.*;

class EmpPay
{
  public static void main(String args[])throws IOException
{
   Emp e=new Emp();
   e.eaccept();
   e.cal_salary();
   e.edisplay();
}
}