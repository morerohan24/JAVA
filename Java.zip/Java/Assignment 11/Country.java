import Game.Indoor;
import Game.Outdoor;

class Country
{
  public static void main(String arg[])
{
  Indoor i=new Indoor("Viswanathan Anand","Sharath Kamal","Mary kom");
  i.idisplay();
  Outdoor o=new Outdoor("Virat Kholi","Ronaldo","Messi");
  o.odisplay();
}
}