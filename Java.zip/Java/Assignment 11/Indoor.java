package Game;
public class Indoor
{
  public String ip1,ip2,ip3;
  
 public Indoor(String s1,String s2,String s3)
{
  ip1=s1;
  ip2=s2;
  ip3=s3;
}
public void idisplay()
{
  System.out.println("Names of players playing indoor games are:-");
  System.out.println("Player 1:"+ip1+" Player 2:"+ip2+" Player 3:"+ip3);
}
}