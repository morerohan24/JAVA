import java.io.*;
public class FileRead
{
  public static void main(String args[])throws IOException
  {
    int i;
    char ch;
    FileInputStream fin=new FileInputStream("DemoFile.java");
    while((i=fin.read())!=-1)
    {
      ch=(char)i;
      if(Character.isDigit(ch))
      {
        System.out.println(ch);
      }
    }
    fin.close();
   }
}