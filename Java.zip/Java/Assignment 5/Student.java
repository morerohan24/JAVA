import java.util.*;
import java.io.*;
public class Student
{
	public int Roll_no;
	public String name,course;
	public double fees;
        Scanner sc=new Scanner(System.in);
	public void Accept()throws IOException
	{
		System.out.println("Enter student Roll number, Name, Course and fees:-");
		Roll_no=sc.nextInt();
		name=sc.next();
		course=sc.next();
		fees=sc.nextDouble();
	}
	public void Display()
	{
	System.out.println("Student Roll number is: "+Roll_no+"\nStudent name is: "+name+"\nStudent Course is: "+course+"\nStudent fees is: "+fees);
	}
	public static void main(String[] args)throws IOException
	{
		Student s1[]=new Student[100];
		int i,n;
		System.out.println("Enter number of student:-");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		System.out.println("Enter student details");
		for(i=0;i<n;i++)
		{
			s1[i]=new Student();
			s1[i].Accept();
		}
		System.out.println("Display student details");
		for(i=0;i<n;i++)
		{
			s1[i].Display();
		}
	}

}