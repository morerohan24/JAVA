import java.util.*;
import java.io.*;

public class Employee
{
  public int eid;
  public String ename,edesignation;
  public double esalary;

public void  eaccept()throws IOException
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter employee id,name,edesignation and salary:");
  eid=sc.nextInt();
  ename=sc.next();
  edesignation=sc.next();
  esalary=sc.nextDouble();
}

public void  edisplay()
{

 System.out.println("Employee id is:"+eid+"\nEmployee name is:"+ename+"\nEmployee edesignation is:"+edesignation+"\nEmployee salary is:"+esalary);

}
 
public static void main(String args[])throws IOException
{
  Employee e1=new Employee();
  e1.eaccept();
  e1.edisplay();

  Employee e2=new Employee();
  e2.eaccept();
  e2.edisplay();


}

}