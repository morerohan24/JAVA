import java.io.*;
import java.util.*;
public class PerfectNo 
{

	public static void main(String[] args)throws IOException 
	{
		int n,i,sum=0;
		i=1;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number to check it is perfect number or not:");
		n=sc.nextInt();
		i=1;   //for(i=1;i<n;i++);
                while(i<n)   // this will not come.
		{
			if(n%i==0)
			{
				sum=sum+i;
			}
                 i++;   // this will not come.
			
		}
		if(n==sum)
		{
			System.out.println(n+" is perfect number");
		}
		else
		{
			System.out.println(n+" is not perfect number");
		}
	}

}