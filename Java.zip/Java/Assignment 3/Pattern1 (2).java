
public class Pattern1
{
public static void main(String[] args)  
{    
	int i,j,sp,n;
	n=4;
	for(i=1;i<=4;i++,n--)
	{
		for(sp=n-1;sp>=1;sp--)
		{
			System.out.print("");
				
		}
		for(j=i;j<=1;j++)
		{
			System.out.print(j+"  ");
		}
		System.out.println(" ");
	}
	}
	}