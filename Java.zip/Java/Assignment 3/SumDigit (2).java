import java.io.*;
import java.util.*;

public class SumDigit 
{

	public static void main(String[] args)throws IOException 
	{
		int ld,num,sum=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number:");
		num=sc.nextInt();
		
		do
		{
			ld=num%10;
			sum=sum+ld;
			num=num/10;
		}
                while(num>0);
		
		System.out.println("The sum digit is:"+sum);
		
	}
}