#include<iostream>
//#include<conio.h>
#include<stdlib.h>
#define MAX 5
using namespace std;
int top,st[MAX];
void intstack()
{
    top=-1;

}
int isfull()
{
    if(top==MAX)
      return 1;
    else
      return 0;
}
int isempty()
{
    if(top==-1)
      return 1;
    else
      return 0;
}
//Function for insertion :-push()
void push(int num)
{
    top++;
    if(isfull())
      cout<<endl<<"Sorry!!! Stack overflow Insertion is not possible";
    else
      st[top]=num;
}
//function for deletion:-pop()
void pop()
{
    if(isempty())
       cout<<endl<<"Sorry!!! Stack Underflow Deletion is not possible";
    else
    {
	cout<<endl<<st[top]<<"is deleted";
	top--;
    }
}
//function to display entire stack
void display()
{
    int i;
    for(i=0;i<=top;i++)
      cout<<endl<<st[i];
}

//function to display only top element of stack
void peak()
{
    cout<<endl<<"The top element is:-"<<st[top];
}

int main()
{
    int num,choice;
    int stack();
    //clrscr();

    do{
	cout<<endl<<"1.pass 1 for insertion";
	cout<<endl<<"2.pass 2 for deletion";
	cout<<endl<<"3.pass 3 for displaying entire stack";
	cout<<endl<<"4.pass 4 for displaying only top element";
	cout<<endl<<"5.pass 5 for exit";
	cout<<endl<<"Enter a choice from 1 to 5:-";
	cin>>choice;
	switch(choice)
	{
	    case 1:
	     cout<<endl<<"Enter a number for insertion:-";
	     cin>>num;
	     push(num);
	     break;
	     case 2:
		pop();
		break;
	     case 3:
		display();
	     case 4:
		peak();
		break;
	     case 5:
		cout<<endl<<"BYE BYE!!";
		//getch();
		exit(3);
	     default:
		 cout<<endl<<"Sorry! Enter a valid choice from 1 to 5 only";
       }
      }while(choice!=5);
      return 0;
}