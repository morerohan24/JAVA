#include<iostream>
using namespace std;
struct Student
{
    int s_id,age;
    char name,gender;
};
int main()
{
    Student s1;
    s1.s_id=111;
    s1.age=20;  
    s1.name='X';
    s1.gender='M';
    cout<<"S_id = "<<s1.s_id<<endl;
    cout<<"S_age = "<<s1.age<<endl;
    cout<<"S_name = "<<s1.name<<endl;
    cout<<"S_gender = "<<s1.gender<<endl;
    return 0;
}