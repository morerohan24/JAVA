//SELECTION SORT
#include<iostream>
using namespace std;
void selection_sort(int ar[],int n)
{
    int pass,i,temp,small;
    for(pass=0;pass<n-1;pass++)
    {
        small=pass;
        for(i=pass+1;i<n;i++)
        {
            if(ar[i]<ar[small])
            small=i;
        }
        temp=ar[small];
        ar[small]=ar[pass];
        ar[pass]=temp;
    }
}
int main()
{
    int a[20],i,n;
    cout<<endl<<"Enter total no of element in array:";
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<endl<<"Enter element for index position "<<i<<":-";
        cin>>a[i];
    }
    selection_sort(a,n);
    cout<<endl<<"Displaying sorted array:-";
    for(i=0;i<n;i++)
      cout<<endl<<a[i];
    return 0;
}