#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;n
class STACK
{
	int info;
	STACK *next;
	public:
	STACK *push(STACK *,int);
	STACK *pop(STACK *);
	void display(STACK *);
	void peak(STACK *);
	STACK init_stack(STACK *);
};
    
//Function fo initialization
 STACK* STACK::init_stack(STACK * list)
{
	list=NULL;
	return list;
}

//Function for insertion
STACK *STACK::push(STACK *list,int num)
{
	STACK *newnode;
	newnode=new STACK;
	newnode->info=num;
	newnode->next=list;
	return newnode;
}

//Function For deletion
STACK *STACK::pop(STACK *list)
{
	if(list==NULL)
	{
		cout<<endl<<"Sorry!! Stack is empty";
		return list;
	}
	STACK *temp=list;
	list=list->next;
	cout<<endl<<temp->info<<"is deleted";
	delete temp;
	return list;
}

//Function to display top element
void STACK::peak(STACK * list)
{
	if(list==NULL)
		cout<<endl<<"Sorry!! Stack is empty";
	else
		cout<<endl<<"Top elemnt is:"<<list->info;
}

//Function to display Entire Stack
void STACK::display(STACK *list)
{
	if(list==NULL)
		cout<<endl<<"Sorry!! Stack is Empty";
	else
	{
		STACK *temp=list;
		while(temp!=NULL)
		{
			cout<<endl<<temp->info;
			temp=temp->next;
		}
	}
}
void main()
{
	int choice,num;
	STACK *head;
	STACK st;
	head=st.init_stack(head);
	clrscr();
	do
	{
		cout<<endl<<"1.Press 1 for Insertion";
		cout<<endl<<"2.Press 2 for Deletion";
		cout<<endl<<"3.Press 3 for Displaying all Elements";
		cout<<endl<<"4.Press 4 for Displaying Top Elements";
		cout<<endl<<"5.Press 5 for exit";
		cout<<endl<<"Enter a choice from 1 to 5";
		cin>>choice;

		switch(choice)
		{
			case 1:
				cout<<endl<<"Enter the number to be inserted";
				cin>>num;
				head=st.push(head,num);
				break;

			case 2:
				head=st.pop(head);
				break;

			case 3:
				st.display(head);
				break;

			case 4:
				st.peak(head);
				break;

			case 5:
				cout<<endl<<"BYE BYE!!!";
				getch();
				exit(1);

			default:
				cout<<endl<<"Sorry ! Wrong number.Enter a number from 1 to 5";
		}
	}while(choice!=5);
}