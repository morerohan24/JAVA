#include<iostream>
using namespace std;
int main()
{
    int i,n,ar[20];
    cout<<"Enter how many element you wnat:-";
    cin>>n;
    cout<<"Enter array element:-";
    for(i=0;i<n;i++)
    {
        cin>>ar[i];
    }
    cout<<"Displya 1-D Array:-";
    for(i=0;i<n;i++)
    {
        cout<<ar[i]<<" ";
    }
    return 0;
}