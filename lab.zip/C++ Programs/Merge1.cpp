#include<iostream>
using namespace std;
void merge(int a[],int low,int mid,int high)
{
    int i,j,k,b[20];
    i=low;
    j=mid+1;
    k=0;
    while((i<=mid) && (j<=high))
    {
        if(a[i]<a[j])
          b[k++]=a[i++];
        else
          b[k++]=a[j++];
    }
 while(i<=mid)
    b[k++]=a[i++];
 while(j<=high)
    b[k++]=a[j++];
 for(i=low,k=0;i<=high;i++,k++)
   a[i]=b[k];
}
void merge_sort(int a[],int low,int high)
{
    int mid;
    if(low<high)
     {
         mid=(low+high)/2;
         merge_sort(a,0,mid);
         merge_sort(a,mid+1,high);
         merge(a,low,mid,high);
     }
}
int main()
{
    int a[20],i,n;
    cout<<endl<<"Enter total no of element in array:";
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<endl<<"Enter element for index position "<<i<<" ";
        cin>>a[i];
    }
    merge_sort(a,0,n);
    cout<<endl<<"Displaying sorted array:-";
    for(i=0;i<n;i++)
      cout<<endl<<a[i];
   return 0;
}