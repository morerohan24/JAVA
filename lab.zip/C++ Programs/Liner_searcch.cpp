#include<iostream>
#include<stdlib.h>
using namespace std;
int Liner_search(int a[],int n,int num)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(a[i]==num)
            return i;
    }
    return -1;
}
int main()
{
    int a[10],n,num,loc,i;
    cout<<"Enter hoe many element you want in array:-";
    cin>>n;
    cout<<"Enter elements in array:-\n";
    for(i=0;i<n;i++)
        cin>>a[i];
    cout<<"Enter number to br search:-";
    cin>>num;
    loc=Liner_search(a,n,num);
    if(loc==-1)
        cout<<"Number not there in array.";
    else
        cout<<"Number is at position:-"<<loc;
    return 0;
}