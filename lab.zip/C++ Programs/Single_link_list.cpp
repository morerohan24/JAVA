#include<iostream>
#include<stdlib.h>
using namespace std;
class NODE
{
    int info;
    NODE * next;
    public:
    NODE * createlist(NODE *);
    void display(NODE *);
    NODE * search(NODE *,int);
    NODE * insret_beg(NODE *,int);
    NODE * insret_end(NODE *,int);
    NODE * insert_pos(NODE *,int,int);
    NODE * delete_pos(NODE *,int)
    NODE * delete_val(NODE *,int);
};
//Funtion to creat a link list.
NODE *NODE :: createlist(NODE *list)
{
    NODE *temp,*newnode;
    int i,n;
    cout<<"\nEnter total number of node to be created:-";
    cin>>n;
    for(i=0;i<=n;i++)
    {
        newnode=new NODE;
        cout<<"Enter the number:-";
        cin>>newnode->info;
        newnode -> next = NULL;
        if(list==NULL)
        {
            list=newnode;
            temp=newnode;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
    }
    return 0;
}
//Function to display the link list.
void NODE :: display(NODE *list)
{
    NODE * temp;
    temp=list;
    while(temp != NULL)
    {
        cout<<endl<<temp->info;
        temp=temp->next;
    }
}
//Function to search a element in a link list.
NODE * NODE :: search(NODE * list,int num)
{
    NODE * temp;
    temp=list;
    while(temp!=NULL)
    {
        if(temp->info==NULL)
            return temp;
        temp=temp->next;
    }
    return NULL;
}
//Function to insert a node at the beginning of link list.
NODE * NODE :: insret_end(NODE * list,int num)
{
    NODE *newnode,*temp;
    newnode =new NODE;
    newnode->next=num;
    newnode->next = NULL;
    temp=list;
    while (temp->next!=NULL)
    {
        temp=temp->next;
    }
    temp->next=newnode;
    if(list==NULL)
        return newnode;
    else
        return list;
}
//Function to insert the node at the given position in the link list.
NODE * NODE :: insert_pos(NODE * list,int pos,int num)
{
    NODE * newnode;
    newnode=new NODE;
    newnode->next=NULL;
    if(pos==1)
    {
        newnode->next=list;
        return list;
    }
    NODE * temp;
    int i;
    temp=list;
    for(i=1;((temp->next != NULL)&&(i<pos-1));i++)
        temp=temp->next;
    newnode -> next = newnode;
    return list;
}
//Function to delete a node by list position in the link list.
NODE * NODE ::delete_pos(NODE * list , int pos)
{
    NODE * temp=list;
    if(pos==1)
    {
        list = list -> next;
        delete temp;
        return list;
    }
    int i;
    for(i=1;((temp->next != NULL)&&(i<pos-1));i++)
        temp = temp -> next;
    if(temp==NULL)
    {
        cout<<"Sorry..!"<<pos<<" Dose not exist in the link list.";
        return list;
    }
    NODE * temp1;
    temp1 -> next -> next;
    temp->next=temp1->next;
    delete temp1;
    return list;
}
//Function to delete a node by it's value.