#include<iostream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int Binary_search(int a[],int n,int num)
{
    int mid,high,low;
    low=0;
    high=n-1;
    while(low<=high)
    {
        mid=(low+high)/2;
        if(a[mid]==num)
            return mid;
        else if(a[mid]<num)
            low=mid+1;
        else if(a[mid]>num)
            high=mid-1;
    }
    return -1;
}
int main()
{
    int i,n,num,loc,ar[10];
    cout<<endl<<"Enter how many array elements you want:-";
    cin>>n;
    cout<<"Enter array element:-";
    for(i=0;i<n;i++)
    {
        cin>>ar[i];
    }
    cout<<endl<<"Enter number to search:-";
    cin>>num;
    loc=Binary_search(ar,n,num);
    if(loc==-1)
        cout<<endl<<"Number is not present.";
    else
        cout<<endl<<"Number is at index position:- "<<loc;
    return 0;
}

