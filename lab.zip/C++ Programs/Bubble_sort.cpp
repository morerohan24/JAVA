#include<iostream>
using namespace std;
int Bubble_sort(int ar[],int n)
{
    int i,temp,pass;
    for(pass=0;pass<n-1;pass++)
    {
        for(i=0;i<n-pass-1;i++)
        {
            if(ar[i]>ar[i+1])
            {
                temp=ar[i];
                ar[i]=ar[i+1];
                ar[i+1]=temp;
            }
        }
    }
}
int main()
{
    int i,n,a[20];
    cout<<"Enter how many array elements you want:-"<<endl;
    cin>>n;
    cout<<"Enter elements in array:-"<<endl;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
    }
    Bubble_sort(a,n);
    cout<<"Sorted elements are:-"<<endl;
    for(i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
    }
    return 0;
}