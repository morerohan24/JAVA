#include<iostream>
using namespace std;
int main()
{
    int n,i,sum=0,ar[20];
    cout<<"Enter how many array elements you want:-";
    cin>>n;
    cout<<"Enter array elements:-";
    for(i=0;i<n;i++)
    {
        cin>>ar[i];
    }
    for(i=0;i<n;i++)
    {
        sum+=ar[i];
    }
    cout<<"Sum of array elements is:-"<<sum;
    return 0;
}