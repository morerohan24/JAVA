//Dynamic implement of Queue
#include<iostream.h>
#include<conio.h>
#include<stdlib.h>
class NODE;
NODE *rear=NULL;
NODE *front=NULL;
class NODE
{
    int info;
    NODE * next;
    public:
    int isempty()
    {
        if(front==NULL)
           return 1;
        else
           return 0;
    }
    void insertion(int n)
    {
        NODE *newnode;
        newnode=new NODE;
        newnode->info=n;
        newnode->next=NULL;
        if(front==NULL)
          front=rear=newnode;
        else
        {
            rear->next=newnode;
            rear=newnode;
        }
    }

void deletion()
{
    if(isempty())
    {
        cout<<endl<<"Sorry Queue is empty Deletion is not possible";
        return;
    }
    NODE *temp;
    temp=front;
    front=front->next;
    delete temp;
    if(front==NULL)
      rear=NULL;
}
void display()
{
    if(isempty())
    {
        cout<<endl<<"Sorry! queue is empty Nothing can be display";
        return;
    }
    NODE * temp;
    for(temp=front;temp!=NULL;temp=temp->next)
      cout<<endl<<temp->info;
}
};
void main()
{
    int choice,num;
    NODE que;
    clrscr();
    do{
        cout<<endl<<"1.Press 1 for insertion";
        cout<<endl<<"2.Press 2 for deletion";
        cout<<endl<<"3.Press 3 for Display";
        cout<<endl<<"4.Press 4 for exit";
        cout<<endl<<"Enter a choice from 1 to 4";
        cin>>choice;
        switch(choice)
        {
            case 1:
              cout<<endl<<"Enter a number:-";
              cin>>num;
              que.insertion(num);
              break;
            case 2:
              que.deletion();
              break;
            case 3:
               que.display();
               break;
            case 4:
               cout<<endl<<"BYE BYE!!";
               getch();
               exit(0);
            default:
               cout<<endl<<"Sorry ! Enter valid choice from 1 to 4";
        }
    }while(choice!=4);
}