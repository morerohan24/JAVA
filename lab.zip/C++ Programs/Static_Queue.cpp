//Static implement of Queue
#include<iostream.h>
#include<conio.h>
#define MAX 5
int que[MAX],rear,front;
void initqueue()
{
    rear=front=-1;
}

int isfull()
{
    if(rear==MAX-1)
      return 1;
    else
      return 0;
}
int isempty()
{
    if(front==-1)
        return 1;
    else 
        return 0;
}
void insert(int num)
{
    if(isfull())
    {
        cout<<endl<<"Sorry! Queue is full Insertion is not allowed";
        return;
    }
    rear++;
    que[rear]=num;
    if(rear==0)
      front=0;
}
void delet()
{
    if(isempty())
    {
        cout<<endl<<"Sorry! Queue is empty deletion is not allowed";
        return;
    }
    cout<<endl<<que[front]<<"is deleted";
    if(front==rear)
       front=rear=-1;
    else
       front++;
}

void display()
{
    if(isempty())
    {
        cout<<endl<<"Sorry! Queue is empty Nothing is for display";
        return;
    }
    int i;
    for(i=front;i<=rear;i++)
      cout<<endl<<que[i];
}

void main()
{
    int choice,n;
    clrscr();
    initqueue();
    do{
        cout<<endl<<"1.Press 1 for insertion";
        cout<<endl<<"2.Press 2 for deletion";
        cout<<endl<<"3. Press 3 for Display";
        cout<<endl<<"4.Press for exit";
        cout<<endl<<"Enter  a choice from 1 to 4:-";
        cin>>choice;
        switch(choice)
        {
            case 1:
              cout<<endl<<"Enter number to be inserted";
              cin>>n;
              insert(n);
              break;
            case 2:
              delet();
	      break;
	    case 3:
	       display();
	       break;
            case 4:
                cout<<endl<<"BYE BYE!!";
                getch();
	       // exit();
            default:
               cout<<endl<<"Sorry wrong choice Enter the right choice";

        }
    }while(choice!=4);
}