//INSERTION SORT
#include<iostream>
using namespace std;
void insertion_sort(int ar[],int n)
{
    int key,k,i;
    for(k=1;k<n;k++)
    {
        key=ar[k];
        for(i=k-1;i>=0;i--)
        {
            if(ar[i]>key)
               ar[i+1]=ar[i];
               else
                 break;
                 ar[i]=key;
        }
    }
}
int main()
{
    int a[20],i,n;
    cout<<endl<<"Enter total no of element in array:";
    cin>>n;
    for(i=0;i<n;i++)
    {
        cout<<endl<<"Enter element for index position "<<i<<" ";
        cin>>a[i];
    }
    insertion_sort(a,n);
    cout<<endl<<"Displaying sorted array:-";
    for(i=0;i<n;i++)
      cout<<endl<<a[i];
    return 0;
}