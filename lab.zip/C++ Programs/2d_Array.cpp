#include<iostream>
using namespace std;
int main()
{
    int i,n,m,j,ar[20][20];
    cout<<"Enter row's:";
    cin>>n;
    cout<<"Enter coloms:";
    cin>>m;
    cout<<"Enter array elements:-";
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            cin>>ar[i][j];
        }
    }
    cout<<"Display Array elements:-";
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            cout<<ar[i][j]<<" ";
        }
    }
    return 0;
}