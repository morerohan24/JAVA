#include<iostream>
#include<stdlib.h>
using namespace std;
class NODE
{
    int info;
    NODE *next;
    public:
    NODE * create_linklist(NODE *);
    void display_linklist(NODE *);
};
//Function to create link list.
NODE *NODE :: create_linklist(NODE *list)
{
    NODE *temp,*newnode;
    int n,i;
    cout<<"Enter how many NODE you want:-";
    cin>>n;
    for(i=0;i<=n;i++)
    {
        newnode=new NODE;
        cout<<"Enter the number:-";
        cin>>newnode->info;
        newnode->next=NULL;
        if(list==NULL)
        {
            list=newnode;
            temp=list;
        }
        else
        {
            temp->next=newnode;
            temp=newnode;
        }
    }
    return list;
}
//Functio to display link list.
void NODE display_linklist(NODE *list)
{
    NODE *temp;
    temp=list;
    while (temp!=NULL)
    {
        cout<<"The value is "<<temp->info<<"  Address is "<<temp->next;
        temp=temp->next;
    }
    
}
int main()
{
    NODE linklist;
    int pos,num,choice;
    NODE *head=NULL;
    do{
        cout<<"Press 1 to create a link list:-";
        switch (choice)
        {
        case 1:
            head=linklist.create_linklist(head);
            break;
        case 2:
            head=linklist.display_linklist(head);
            break;
        default:
            break;
        }
    }while(choice!=9)
    return 0;
}