import java.applet.*;
import java.awt.*;

/*<applet code="DemoApplet" width=300 height=300></applet>*/

public class DemoApplet extends Applet
{
public void paint(Graphics g)
{
	
	g.drawString("Hello World",20,20);
        g.drawLine(50,50,100,100);
	g.drawLine(50,50,0,100);
        g.drawRect(0,100,100,100);
       g.drawRect(50,150,30,50);

       g.drawOval(200,50,50,50);
g.drawOval(220,70,10,10);
g.drawOval(240,70,10,10);
g.drawArc(240,100,30,30,0,-180);
}

}