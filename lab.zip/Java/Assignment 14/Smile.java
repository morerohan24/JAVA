import java.awt.*;
import java.applet.*;

//<applet code=Smile width=1800 height=900></applet>
public class Smile extends Applet{
    public void paint(Graphics g) {
        g.drawString("Hello World",100,100);
        g.drawOval(500,300,400,400);
        g.drawOval(600,400,40,40);
        g.drawOval(750,400,40,40);
        g.drawLine(690,450,690,530);
        g.drawArc(670,550,50,50,180,180);
    }
}
