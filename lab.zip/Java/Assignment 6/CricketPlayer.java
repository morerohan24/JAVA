import java.io.*;
import java.util.*;
public class CricketPlayer
{
    public String name;
    public int total_run,inning_played,not_out;
    CricketPlayer(String p, int t, int ip, int out)
    {
        name=p;
        total_run=t;
        inning_played=ip;
        not_out=out;
     }
     
     public void display()
     {
         System.out.println ("Player name:"+name+"\n Player total run is:"+total_run+"\n Players inning played is:"+inning_played+"\n Player not out is:"+not_out);
     }
    
     public void average_runs()
     {
       int avg;
       avg=(total_run/(inning_played-not_out));
       System.out.println("Player Average run is:"+avg);
     }

     public static void  main(String args[])throws IOException 
     {
        CricketPlayer c[]= new CricketPlayer[100];
        int  i, n , t , ip, out;
        String p;
        Scanner sc= new Scanner (System.in);
       
        System.out.println ("Enter how many player you want:");
        n=sc.nextInt ();
        System.out.println("Enter players details:");  
        for (i=0; i<n; i++)
        {
          System.out.println("Enter player name:");
          p=sc.next();
          System.out.println("Enter player total runs:");
          t=sc.nextInt();
          System.out.println("Enter player inning played: ");
          ip=sc.nextInt();
          System.out.println("Enter player not out:");
          out=sc.nextInt();
          c[i] =new CricketPlayer(p,t,ip,out);    
       } 

       System.out.println("Display players details:");  
       for (i=0; i<n; i++)
       {
        c[i].display();
        c[i].average_runs();
       }
   }
}