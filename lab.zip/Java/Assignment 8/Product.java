public class Product 
   {
      public String pname;
      public double  price;
      static int count=0;
	        
	        
      Product()
      {
	pname="laptop";
       	price=50000;
      	count++;
      }
	        
      Product(String pn,double p)
      {
	pname=pn;
	price=p;
	count++;
      }
	        
      public void pdisplay()
      {
	   System.out.println("product name is:"+pname+ "\t price is:"+price);
      }
	        
      public static void main(String[] args)
      {
	  Product p1=new Product();
	  p1.pdisplay();
	  Product p2=new Product("TV",30000.5);
	  p2.pdisplay();
	  System.out.println("No of product is:"+count);
      }
	      
}