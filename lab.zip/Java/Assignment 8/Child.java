class Parent
{
  int x,y;
  Parent(int a)
  {
    x=a;
  }
  Parent(int a,int b)
  {
    x=a;
    y=b;
  }
  
  public void pdisplay()
  {
    System.out.println("Parent value is:"+x+ "  "+y);
  }
}
public class Child extends Parent
{
  public int x,z;
  Child(int a,int b)
  {
     super(a);
     z=b;
  }
  public void cdisplay()
  {
    System.out.println("Parent value is:"+super.x+ "  "+y);
    System.out.println("Child value is:"+this.x+ "  "+z);
  }
  Child(int a,int b,int c)
  {
    super(a,b);
    z=c;
  }
public static void main(String args[])
{
  Child c1=new Child(11,42);
  c1.cdisplay();
  Child c2=new Child(1,2,3);
  c2.cdisplay();
}
}