import java.awt.*;
import java.awt.event.*;

public class GuiScreen extends Frame implements ActionListener 
{
	Label l1,l2,l3,l4;
	TextField t1,t2,t3;
	Button b1,b2;
	
		
	GuiScreen()
	{
		l1=new Label("Name");
		l2=new Label("Class");
		l3=new Label("Hobbies");
		l4=new Label();
		
		t1=new TextField();
		t2=new TextField();
		t3=new TextField();
		
		b1=new Button("Submit");
		b2=new Button("Cancel");
			
			
		add(l1);
		add(t1);
		
		add(l2);
		add(t2);
		
		add(l3);
		add(t3);
		
		add(b1);
		add(b2);
		
		add(l4);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
			
		setSize(500,500);
		setFont(new Font("Arial",Font.BOLD,50));
		setLayout(new GridLayout(5,2));
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String name=e.getActionCommand();
		String s1,s2,s3,res;
		if(name.equals("Submit"))
		{
			s1=t1.getText();
			s2=t2.getText();
			s3=t3.getText();
			res="Submitted details:"+s1+s2+s3;
			l4.setText(res);
		}
		else
		{
			if(name.equals("Cancel"))
			{
				l4.setText("From is Cancelled");
			}
		}
	}
	
		public static void main(String args[])
		{
			GuiScreen g1=new GuiScreen();
		
		}
}