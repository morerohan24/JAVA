import java.io.*;
class Division
{
  public int a,b,c;
  public static void main(String args[])
  {
    Division d1=new Division();
    int a[]=new int[3];
    d1.a=Integer.parseInt(args[0]);
    d1.b=Integer.parseInt(args[1]);
  try
  {
    d1.c=d1.a/d1.b;
  }
  catch(ArithmeticException e)
  {
    e.printStackTrace();
  }
  try
  {
    a[5]=8;
  }
  catch(ArrayIndexOutOfBoundsException e1)
  {
    e1.printStackTrace();
  }
  System.out.println("Division is:"+d1.c);
 }
}