import java.util.*;
public class GreatestNo 
{

	public static void main(String[] args) 
	{
	   int a,b,c;
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter first no:");
	   a=sc.nextInt();
	   System.out.println("Enter second no:");
	   b=sc.nextInt();
	   System.out.println("Enter third no:");
	   c=sc.nextInt();
	   if(a>b && a>c)
	   {
		   System.out.println(a+" is a greater no.");
	   }
	   else if(b>a && b>c)
	   {
		   System.out.println(b+" is a greater no.");
	   }
	   else
	   {
		   System.out.println(c+" is a greater no.");
	   }  
	 }
}
