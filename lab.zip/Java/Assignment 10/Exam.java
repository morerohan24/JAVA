interface Test
{
  public void paper();
}
public class Exam implements Test
{
  public String q1,q2,q3;
  public void paper()
{
  q1="What is oop's?";
  q2="What is super class?";
  q3="What is final keyword?";
  System.out.println("Que 1:"+q1+"\nQue 2:"+q1+"\nQue 3:"+q3);
}

public static void main(String args[])
{
  Exam e1=new Exam();
  e1.paper();
}
}