public class Pattern
{
  public static void main(String args[])
  {
    int i,j;
    char ch;
    for(i=1;i<=3;i++)
    {
      for(j=1,ch='a';j<=i;j++,ch++)
      {
         System.out.print(ch+" ");
      }
      System.out.println(" ");
    }
    for(i=2;i>=1;i--)
    {
      for(j=1,ch='a';j<=i;j++,ch++)
      {
        System.out.print(ch+" ");
      }
      System.out.println(" ");
    }
  }
}