import java.io.*;
import java.util.*;
public class Armstrong 
{

	public static void main(String[] args)throws IOException 
	{
	   int num,temp,ld,sum=0;
	   Scanner sc=new Scanner(System.in);
	   System.out.println("Enter Number to check it is armstrong or not:");
	   num=sc.nextInt();
	   temp=num;
	   for(temp=num;num>0;num=num/10)
	   {
	     ld=num%10;
	     sum=sum+(ld*ld*ld);
	   }
				
	  if(sum==temp)
	  {
	    System.out.println(sum+" Is Armstrong Number");
	  }
	  else
	  {
	     System.out.println(sum+" Is Not Armstrong Number");
	  }
      }
}
	


