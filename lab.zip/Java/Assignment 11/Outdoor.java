package Game;
public class Outdoor
{
  public String op1,op2,op3;
  
 public Outdoor(String s1,String s2,String s3)
{
  op1=s1;
  op2=s2;
  op3=s3;
}
public void odisplay()
{
  System.out.println("Names of players playing outdoor games are:-");
  System.out.println("Player 1:"+op1+" Player 2:"+op2+" Player 3:"+op3);
}
}