import java.util.*;
import java.io.*;

public class EvenOdd
{
  public static void main(String args[])throws IOException
    {
      int a[]=new int[100];
      int i,n;
      Scanner sc=new Scanner(System.in);
      System.out.println("How many no's you want to enter:");
      n=sc.nextInt();
      System.out.println("Accept no's:");
      for(i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
      System.out.println("Even no are:");
      for(i=0;i<n;i++)
    {
      if(a[i]%2==0)
       {
         System.out.println(+a[i]);
       }
    
    }  
     System.out.println("odd no are:");
      for(i=0;i<n;i++)
    {
      if(a[i]%2!=0)
       {
         System.out.println(+a[i]);
       }
    
    }      
        
     }
}