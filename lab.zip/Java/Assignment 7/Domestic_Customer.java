import java.util.*;
import java.io.*;
class Electricity_Bill
{
  public int consumer_no;
  public double units;
  public String consumer_name,month;
  Scanner sc=new Scanner(System.in);

  public void eaccept()throws IOException
  {
     System.out.println("enter the number,name,month & unit");
     consumer_no=sc.nextInt();
     consumer_name=sc.next();
     month=sc.next();
     units=sc.nextDouble();
  }
  
  public void edisplay()throws IOException
  {
    System.out.println("consumer number:="+consumer_no + " consumer name:="+ consumer_name + "month:="+month +"units:=" +units);         
  }
}

public class Domestic_Customer extends Electricity_Bill
{ 
  public double bill_amount;
  
  public void calculate_bill()
  {
     if (units<=100)
     {
       bill_amount=1*units;
     }

       else
       {
         if(units>100 && units <=200)
           {
              bill_amount=2.5*units;
           }
          else
            {
              if(units>200 && units <=500)
               {
                 bill_amount=4*units;
               }
                else
                 {
                   if(units>=501)
                    {
                      bill_amount=6*units;
         
                    }
      
                 }
      
            }
        }
   System.out.println("Bill amount is"+bill_amount);
    }
  public static void main(String[] args)throws IOException
{
  Scanner sc=new Scanner(System.in);
  Domestic_Customer c[]=new Domestic_Customer[100];
  int i,n;
  System.out.println("Enter no of customer:");
  n=sc.nextInt();
  System.out.println("Enter customer details:");
  for(i=0;i<n;i++)
  {
    c[i]=new Domestic_Customer();
    c[i].eaccept();
  }
  System.out.println("Display customer details:");
  for(i=0;i<n;i++)
  {
    c[i].calculate_bill();
    c[i].edisplay();
  } 
}
}